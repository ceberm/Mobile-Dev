package com.example.calculadora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private long _firstValue = 0;
    private long _secondValue = 0;
    private String _str = "";
    private char _op = ' ';

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupUI();
    }

    private void initializeVariables(){
         _firstValue = 0;
         _secondValue = 0;
         _str = "";
         _op = ' ';
    }

    private Long validateValue(String value){
        if (!value.contains(".") && !value.contains(","))
            try{
                return Long.valueOf(value);
            }catch(NumberFormatException nfex){
                initializeVariables();
                Toast.makeText(getApplicationContext(), nfex.getMessage(), Toast.LENGTH_LONG).show();
            }
        else {
            Toast.makeText(getApplicationContext(), "Las operaciones decimales no son soportadas por el momento", Toast.LENGTH_LONG).show();
            initializeVariables();
        }
        return null;
    }

    private void setupUI()
    {
        final EditText mTextView = (EditText) findViewById(R.id.inputNumber);

        final TextView firstValueLabel = (TextView) findViewById(R.id.textView);

//--------------------------------------------------------------------------------------------------
        Button button_0 = (Button) findViewById(R.id.button_0);
        Button button_1 = (Button) findViewById(R.id.button_1);
        Button button_2 = (Button) findViewById(R.id.button_2);
        Button button_3 = (Button) findViewById(R.id.button_3);
        Button button_4 = (Button) findViewById(R.id.button_4);
        Button button_5 = (Button) findViewById(R.id.button_5);
        Button button_6 = (Button) findViewById(R.id.button_6);
        Button button_7 = (Button) findViewById(R.id.button_7);
        Button button_8 = (Button) findViewById(R.id.button_8);
        Button button_9 = (Button) findViewById(R.id.button_9);
        Button button_clear = (Button) findViewById(R.id.button_clear);
        Button button_equal = (Button) findViewById(R.id.button_equal);
        Button button_mul = (Button) findViewById(R.id.button_mul);
        Button button_res = (Button) findViewById(R.id.button_res);
        Button button_sum = (Button) findViewById(R.id.button_sum);
        Button button_div = (Button) findViewById(R.id.button_div);

        button_div.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if (_op == ' ' && _firstValue == 0) {
                    _op = 'D';
                    _firstValue = validateValue(_str);
                }

                firstValueLabel.setText(_str);
                _str = "";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);


            }
        });

        button_res.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if (_op == ' ' && _firstValue == 0) {
                    _op = 'R';
                    _firstValue = validateValue(_str);
                }

                firstValueLabel.setText(_str);
                _str = "";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);


            }
        });



        button_mul.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                if (_op == ' ' && _firstValue == 0) {
                    _op = 'M';
                    _firstValue = validateValue(_str);
                }

                firstValueLabel.setText(_str);
                _str = "";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);


            }
        });

        button_equal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Long result = new Long(0);

                _secondValue = validateValue(_str);

                if (_op != ' '  &&_firstValue != 0 && _secondValue !=0){
                    if(_op == 'R')result=_firstValue-_secondValue;
                    else
                    if(_op == 'S')result=_firstValue+_secondValue;
                    else
                    if(_op == 'M')result=_firstValue*_secondValue;
                    else {
                        if (_op == 'D' && _secondValue > _firstValue) {
                            result = _firstValue / _secondValue;
                        } else {
                            Toast.makeText(getApplicationContext(), "La division por cero no esta permitida", Toast.LENGTH_LONG).show();
                            Log.i("MainActivity", "Activity Log :: Number one is: " + _firstValue + " Number Two:" + _secondValue);
                        }
                    }

                    Intent intent = new Intent();
                    intent.setClass(getApplicationContext(), ResultsActivity.class);
                    intent.putExtra("EXTRA_RESULT", "El resultado es: "+result.toString());
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "Ha ocurrido un error inesperado", Toast.LENGTH_LONG).show();
                    Log.i("MainActivity", "Activity Log :: Number one is: " + _firstValue + " Number Two:" + _secondValue);
                }

                initializeVariables();
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);

            }
        });

        button_sum.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if (_op == ' ' && _firstValue == 0) {
                    _op = 'S';
                    _firstValue = validateValue(_str);
                }

                firstValueLabel.setText(_str);
                _str = "";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);


            }
        });

        button_clear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                initializeVariables();

                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);

            }
        });

        button_0.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                _str += "0";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "1";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "2";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "3";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "4";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "5";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "6";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "7";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_8.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "8";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });

        button_9.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(_str.length()<10)
                    _str += "9";
                EditText inputNumber = (EditText) findViewById(R.id.inputNumber);
                mTextView.setText(_str);
                Log.i("MainActivity", "Activity Log :: Number one is: " + _str);

            }
        });
    }
}
