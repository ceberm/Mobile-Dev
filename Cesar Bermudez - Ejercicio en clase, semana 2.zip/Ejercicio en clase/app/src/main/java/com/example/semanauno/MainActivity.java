package com.example.semanauno;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String TAG="MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG,"Estoy en onCreate");
        setupUI();

        //solo como un FYI siempre se de be hacer un thread como una tarea asincrona

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public void setContent(String html){
        EditText content = (EditText) findViewById(R.id.showContent);

        content.setText(html);
    }

    public void getHtmlContent(){

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"Estoy en onStart");
    }

    @Override
    protected void onStop() {
        Log.i(TAG,"Estoy en onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG,"Estoy en onDestroy");
        super.onDestroy();
    }

    @Override
    protected  void onRestart(){
        super.onRestart();
        Log.i(TAG,"Estoy en onRestart");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i(TAG,"Estoy en onResume");
    }
    /*

     */
    public boolean hasInternetAccess(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        return netInfo != null && netInfo.isConnectedOrConnecting();

    }

    /*
        Descargar el html y mostrarlo
     */

    private void getUrlContent(String url)throws IOException {
        String res = "";
        URL urlToFetch = new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) urlToFetch.openConnection();
        InputStream stream = urlConnection.getInputStream();
        res = readStream(stream);
        EditText showContent = (EditText) findViewById(R.id.showContent);
        showContent.setText(res);
        urlConnection.disconnect();
    }

    public String readStream(InputStream stream){
        Reader reader = new InputStreamReader(stream);
        BufferedReader buffer = new BufferedReader(reader);
        StringBuilder response = new StringBuilder();
        String chunkJustRead = "";
        try{
            while((chunkJustRead = buffer.readLine()) != null)
                response.append(chunkJustRead).append('\n');

        }catch (IOException ioex){
            ioex.printStackTrace();
        }

        return response.toString();
    }

    public String inputStream_ToString(InputStream input)throws IOException{
        BufferedReader r = new BufferedReader(new InputStreamReader(input));
        StringBuilder total = new StringBuilder();
        for (String line; (line = r.readLine()) != null; ) {
            total.append(line).append('\n');
        }

        return total.toString();
    }

    private void setupUI()
    {
//--------------------------------------------------------------------------------------------------
        Button btn = findViewById(R.id.btn_descargar);

        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                CharSequence text = "";
                int duration = Toast.LENGTH_SHORT;

                if(hasInternetAccess()){
                    text="Has Internet Access";
                    EditText url = (EditText) findViewById(R.id.urlEditText);
                    try{
                        getUrlContent(url.getText().toString());
                    }catch (IOException ioex){
                        text = "El URL no pudo ser leido";
                    }
                }else{
                    text="No Internet Access";
                }
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });
//--------------------------------------------------------------------------------------------------

    }
}
