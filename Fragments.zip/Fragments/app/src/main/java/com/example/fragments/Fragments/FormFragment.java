package com.example.fragments.Fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.fragments.FormActivity;
import com.example.fragments.R;
import com.example.fragments.models.Persona;

/**
 * A simple {@link Fragment} subclass.
 */
public class FormFragment extends Fragment {


    public FormFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_form, container, false);
        setupUI(view);
        return view;
    }

    public void setupUI(View view){
        Button btn = (Button) view.findViewById(R.id.btnSubmit);
        final EditText etNombre = (EditText) view.findViewById(R.id.etNombre);
        final EditText etApellido = (EditText) view.findViewById(R.id.etApellido);
        final EditText etCorreo = (EditText) view.findViewById(R.id.etCorreo);
        final EditText etNum = (EditText) view.findViewById(R.id.etNum);


        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //TODO





                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ShowFragment showFragment = new ShowFragment();
                Bundle bundle = new Bundle();
                Persona persona = new Persona(etNombre.getText().toString(),etApellido.getText().toString(),
                        etCorreo.getText().toString(),etNum.getText().toString());
                bundle.putSerializable("Persona", persona);
                showFragment.setArguments(bundle);
                ft.replace(android.R.id.content, showFragment);
                ft.addToBackStack(null); //Add fragment in back stack
                ft.commit();

                /*
                Intent intent = new Intent(getContext(), FormActivity.class);
                getActivity().startActivity(intent);
                getActivity().finish();*/
            }
        });
    }

}
